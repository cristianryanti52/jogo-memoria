const grid = document.querySelector('.grid');
const spanPlayer = document.querySelector('.player');
const timer = document.querySelector('.timer');


// Seleciona as imagens dentro da pasta
const character = [
    'android17',
    'Bills',
    'bulma',
    'FREEZA',
    'goku',
    'goha',
    'majinboo',
    'mestrekame',
    'Vegeta',
    'piccolo',
];


const createElement = (tag, className) => {
    const element = document.createElement(tag);
    element.className = className;
    return element;

}

let firstCard = '';
let secondCard = '';


// Verica se o jogador virou todas as cartas
const checkEndGame = () => {
    const disabledCards = document.querySelectorAll('.disabled-card');

    if(disabledCards.length == 20){
        clearInterval(this.loop);
        alert(`Parabéns, ${spanPlayer.innerHTML}! Seu tempo foi:${timer.innerHTML}`);
    }
}


// esquema de validações das cartas
const checkCards = () => {

    const firstCharacter = firstCard.getAttribute('data-character');
    const secondCharacter = secondCard.getAttribute('data-character');

    if (firstCharacter == secondCharacter) {

        firstCard.firstChild.classList.add('disabled-card');
        secondCard.firstChild.classList.add('disabled-card');

        firstCard = '';
        secondCard = '';

        checkEndGame();


    } else {

        setTimeout(() => {

        firstCard.classList.remove('reveal-card');
        secondCard.classList.remove('reveal-card');

        firstCard = '';
        secondCard = '';

        }, 500);

        
    }
}

// Revela as cartas
const revealCard = ({ target }) => {

    if(target.parentNode.className.includes('reveal-card')) {
        return;
    }


    if (firstCard == ''){

        target.parentNode.classList.add('reveal-card');
        firstCard = target.parentNode;

    } else if (secondCard == ''){

        target.parentNode.classList.add('reveal-card');
        secondCard = target.parentNode;
    }

    checkCards();


    
}

// Cria as cartas da aplicação
const createCard = (character) => {
   
    const card = createElement('div','card');
    const front = createElement('div','face front');
    const back = createElement('div','face back');

    front.style.backgroundImage = `url('../imagens/${character}.jpg')`;


    card.appendChild(front);
    card.appendChild(back);

    card.addEventListener('click', revealCard);
    card.setAttribute('data-character', character)


    return card;
}

// roda a aplicação
const loadGame = () => {
   
    const duplicateCharacter = [ ...character, ...character ];

    const shuffleadArray = duplicateCharacter.sort( () => Math.random() -0.5);


    shuffleadArray.forEach((character) => {
        const card = createCard(character);
        grid.appendChild(card);
    })
}


// tempo do jogo
const startTimer = () => {

    this.loop = setInterval(() =>{

        const currenTime = +timer.innerHTML;
        timer.innerHTML = currenTime + 1;
        }, 1000) ;
}

// puxa o nome do localstorage
window.onload = () => {

    spanPlayer.innerHTML = localStorage.getItem('player');

    startTimer();
    loadGame();
}


